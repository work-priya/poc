package com.example.chatbot.controller;

import com.example.chatbot.model.Ticket;
import com.example.chatbot.repository.TicketRepository;
import com.example.chatbot.service.TicketService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import java.io.IOException;

@RestController
@RequestMapping("/api/tickets")
public class TicketController {

    private final TicketRepository ticketRepository;
    private final TicketService ticketService;

    public TicketController(TicketRepository ticketRepository, TicketService ticketService) {
        this.ticketRepository = ticketRepository;
        this.ticketService = ticketService;
    }

    @PostMapping(value = "/create", consumes = "multipart/form-data")
    public ResponseEntity<String> createTicket(@RequestPart("description") String description,
                                               @RequestPart("screenshot") MultipartFile screenshot) throws IOException {
        String screenshotPath = ticketService.saveScreenshot(screenshot);
        Ticket ticket = new Ticket();
        ticket.setDescription(description);
        ticket.setScreenshotPath(screenshotPath);
        ticketRepository.save(ticket);
        return ResponseEntity.ok("Ticket Created Successfully!");
    }

    @GetMapping
    public ResponseEntity<?> getAllTickets() {
        return ResponseEntity.ok(ticketRepository.findAll());
    }
}