package com.example.chatbot.service;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import java.io.*;

@Service
public class TicketService {

    public String saveScreenshot(MultipartFile file) throws IOException {
        String filePath = "uploads/" + file.getOriginalFilename();
        File saveFile = new File(filePath);
        file.transferTo(saveFile);
        return filePath;
    }
}