package com.example.chatbot.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import com.example.chatbot.model.Ticket;

public interface TicketRepository extends MongoRepository<Ticket, String> { }