@Component({ selector: 'app-root', templateUrl: './app.component.html' })
export class AppComponent {
    tickets = [];
    issue = '';

    constructor(private ticketService: TicketService) {}

    submitTicket() {
        this.ticketService.createTicket(this.issue).subscribe(ticket => {
            this.issue = '';
            this.loadTickets();
        });
    }

    loadTickets() {
        this.ticketService.getTickets().subscribe((data: any) => this.tickets = data);
    }

    ngOnInit() {
        this.loadTickets();
    }
}