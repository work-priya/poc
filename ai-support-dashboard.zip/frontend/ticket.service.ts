@Injectable({ providedIn: 'root' })
export class TicketService {
    constructor(private http: HttpClient) {}

    createTicket(description: string) {
        return this.http.post('/api/tickets/create', { description });
    }

    getTickets() {
        return this.http.get('/api/tickets');
    }
}