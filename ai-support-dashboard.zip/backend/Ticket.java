@Document
public class Ticket {
    @Id
    private String id;
    private String description;
    private String status;
    private LocalDateTime createdAt;

    // constructors, getters, setters
}