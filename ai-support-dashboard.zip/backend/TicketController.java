@RestController
@RequestMapping("/api/tickets")
public class TicketController {

    @Autowired
    private TicketRepository ticketRepo;

    @Autowired
    private OpenAIService openAIService;

    @PostMapping("/create")
    public ResponseEntity<Ticket> createTicket(@RequestBody TicketRequest request) {
        String summary = openAIService.summarizeIssue(request.getDescription());
        Ticket ticket = new Ticket(summary, "Open", LocalDateTime.now());
        return ResponseEntity.ok(ticketRepo.save(ticket));
    }

    @GetMapping
    public List<Ticket> getAllTickets() {
        return ticketRepo.findAll();
    }
}