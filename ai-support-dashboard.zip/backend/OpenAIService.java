@Service
public class OpenAIService {
    private static final String OPENAI_URL = "https://api.openai.com/v1/chat/completions";
    private static final String API_KEY = "YOUR_API_KEY";

    public String summarizeIssue(String userInput) {
        // Send request to OpenAI API and return the summary
        // Use WebClient or RestTemplate
        return "AI summarized issue"; // Stub
    }
}